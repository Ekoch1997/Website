function inputExample(){
    document.getElementById("inputText").textContent = `/if(/index($_Report Type.List Name$,Monthly Holdings,Monthly Transactions, Report Update)>0,Monthly Report,$_Page Header Type.Plan Update$)/if($_Page Header Type.Show Month Name$=1,/if($_Frequency.Type$!=Daily," - /formatdate($_Date.SysDate$,"mmmm yyyy")",)/if($_Frequency.Type$=Daily, - /formatdate($_Date.SysDate$,"mm/dd/yyyy"),),)/if($_Page Header Type.Show Date Range$=1, - /formatdate(/if($_Frequency.Type$=YTD,/date(1,1,/year($_Date.SysDate$)),/if($_Frequency.Type$=Weekly,$QueriedStartDate$,/if($_Frequency.Type$=Since Inception,$InceptionDate$,/firstdayofmonth(/addmonths($_Date.SysDate$,$_Frequency.MonthOffset$))))),"mm/dd/yy") through /formatdate($_Date.SysDate$,"mm/dd/yy"),)`
}

function formatter(){
    let text = document.getElementById("inputText").value
    let formattedText = ``
    let indents = 0
    let parentheses = 0
    let doubleQuote = 0
    let singleQuote = 0
    let ifStates = []
    let ifParenthOffset = []
    let ifCounter = 0
    let newLineToggle = 1

    queue = [text]

    while (text != ''){
        
        if (text.indexOf('/if(') == 0){

            if (formattedText != '' && newLineToggle == 1){
                formattedText += '\n\n'
                formattedText += '      '.repeat(indents)
            }
            formattedText += 'IF '
            indents += 1
            ifStates.push(0) // 0 = clause, 1 = true, 2 = false
            ifParenthOffset.push(parentheses)
            text = text.slice(text.indexOf('/if(')+'/if('.length);

        }

        else if (text.indexOf(',)') == 0 && ifParenthOffset[ifParenthOffset.length - 1] == parentheses && singleQuote % 2 == 0 && doubleQuote % 2 == 0){ // False clause but no data, we don't want to print the ELSE
            indents--
            //formattedText += '\n\n'
            //formattedText += '      '.repeat(indents)
            ifStates.pop()
            ifParenthOffset.pop()
            text = text.slice(2)

        }
        else if (text.indexOf(',') == 0 && ifParenthOffset[ifParenthOffset.length - 1] == parentheses && singleQuote % 2 == 0 && doubleQuote % 2 == 0){
            if (ifStates[ifStates.length-1] == 0){ // True Clause
                formattedText += ' THEN'
                formattedText += '\n\n'
                formattedText += '      '.repeat(indents)
                newLineToggle = 0
                ifStates[ifStates.length-1] = 1
            }
            else if (ifStates[ifStates.length-1] == 1){ // False Clause with logic in the else statement
                formattedText += '\n\n'
                formattedText += '      '.repeat(indents - 1)
                formattedText += 'ELSE'
                formattedText += '\n\n'
                formattedText += '      '.repeat(indents)
                newLineToggle = 0
                ifStates[ifStates.length-1] = 2
            }
            text = text.slice(1)
        }

        else if (text.indexOf(')') == 0 && ifParenthOffset[ifParenthOffset.length - 1] == parentheses && singleQuote % 2 == 0 && doubleQuote % 2 == 0){
            indents--
            ifStates.pop()
            ifParenthOffset.pop()
            if (newLineToggle == 1 && text.indexOf('))') != 0){
                formattedText += '\n\n'
                formattedText += '      '.repeat(indents)
                newLineToggle = 0
            }
            text = text.slice(1)
        }
        
        else{
            char = text[0]

            if (char == '('){
                parentheses++
            }
            else if (char == ')'){
                parentheses--
            }
            else if (char == '"'){
                doubleQuote++
            }
            else if (char == "'"){
                singleQuote++
            }

            formattedText += text[0]
            newLineToggle = 1
            text = text.slice(1)
        }
        
        if (text.indexOf('Start Month Diff') == 0){
            continue
        }
        
        //console.log(formattedText);
    }

    //console.log(formattedText)
    document.getElementById("outputText").textContent = formattedText
}